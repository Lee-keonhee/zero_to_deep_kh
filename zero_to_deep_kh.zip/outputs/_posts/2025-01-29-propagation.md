---
layout: post
title: 순전파/ 역전파 예제로 이해하기
summary: 순전파와 역전파의 계산을 통해, 가중치의 최적화 과정 확인
author: keonhee
date: 2025-01-29 16:20:00 +0900
category: 딥러닝기초
keywords: 딥러닝, 순전파, 역전파, 신경망
permalink: /blog/propagation/
usemathjax: true
thumbnail: /assets/img/posts/propagation_thumbnail.png
---

# 순전파와 역전파 이해하기

신경망 학습의 핵심 메커니즘인 순전파(Forward Propagation)와 역전파(Backpropagation)에 대해 알아보겠습니다.

## 순전파 (Forward Propagation)

순전파는 입력 데이터가 신경망을 통과하여 출력을 생성하는 과정입니다.

### 수식

$$
z = w \cdot x + b
$$

$$
a = \sigma(z)
$$

여기서:
- $x$: 입력값
- $w$: 가중치
- $b$: 편향
- $\sigma$: 활성화 함수

## 역전파 (Backpropagation)

역전파는 출력의 오차를 이용하여 가중치를 업데이트하는 과정입니다.

### 손실 함수

$$
L = \frac{1}{2}(y - \hat{y})^2
$$

### 가중치 업데이트

$$
w_{new} = w_{old} - \eta \frac{\partial L}{\partial w}
$$

## 예제 코드

```python
import numpy as np

def sigmoid(x):
    return 1 / (1 + np.exp(-x))

def forward_pass(x, w, b):
    z = np.dot(w, x) + b
    a = sigmoid(z)
    return a

# 예제 실행
x = np.array([1.0, 2.0])
w = np.array([0.5, 0.3])
b = 0.1

output = forward_pass(x, w, b)
print(f"출력: {output}")
```

## 결론

순전파와 역전파는 신경망 학습의 핵심 메커니즘입니다. 이를 통해 가중치가 최적화되며, 모델의 성능이 향상됩니다.
